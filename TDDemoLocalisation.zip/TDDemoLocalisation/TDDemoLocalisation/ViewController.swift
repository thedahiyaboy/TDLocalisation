//
//  ViewController.swift
//  TDDemoLocalisation
//
//  Created by dahiyaboy on 14/03/18.
//  Copyright © 2018 dahiyaboy. All rights reserved.
//

/*
 -----REFERENCES
 https://useyourloaf.com/blog/natural-text-alignment-for-rtl-languages/
 // As stated nature alignment is used for RTL or LTR. It is not working.
 https://developer.apple.com/documentation/uikit/uiview/1622461-semanticcontentattribute
 // semantics on uiview appearnce not working.
 
 -- Medium
 https://medium.com/@prabhakarpatil648/uiview-appearance-semanticcontentattribute-forcerighttoleft-doesnt-work-159d633476b6
 // check comment, there OP stated that he forget to reload all views. So how to reload all views?
 
 -- stack question
 https://stackoverflow.com/questions/49277773/semanticcontentattribute-is-not-working
 
 */

import UIKit
import Localize_Swift

class ViewController: UIViewController {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var containerSample: UIView!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var viewName: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        Localize.setCurrentLanguage("en")
        
        imgView.image = UIImage(named: "flag".localized())
        lblTitle.text = "Title".localized()
        lblDescription.text = "Description".localized()        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        NotificationCenter.default.addObserver(self, selector: #selector(setText), name: NSNotification.Name(LCLLanguageChangeNotification), object: nil)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
    }
    
    @objc func setText(){
        
        let cur_lang = Localize.currentLanguage()
        print("current lang; \(cur_lang)")
        if cur_lang == "ar"{
            UIView.appearance().semanticContentAttribute = .forceRightToLeft
        }
        else{
            UIView.appearance().semanticContentAttribute = .forceLeftToRight
        }
        
        if UIView.userInterfaceLayoutDirection(for: self.view.semanticContentAttribute) == UIUserInterfaceLayoutDirection.rightToLeft{
            print("rightToLeft")
            
        }
        else if UIView.userInterfaceLayoutDirection(for: self.view.semanticContentAttribute) == UIUserInterfaceLayoutDirection.leftToRight {
            print("leftToRight")
        }
        
        imgView.image = UIImage(named: "flag".localized())
        lblTitle.text = "Title".localized()
        lblDescription.text = "Description".localized()
        lblName.text = "Name".localized()
        tfName.text = "textName".localized()
    }
    
    @IBAction func btnChangeLang(_ sender: Any) {
        let alertController = UIAlertController(title: "", message: "Select Language".localized() , preferredStyle: .actionSheet)
        
        let arAction = UIAlertAction(title: "Arabic".localized() , style: UIAlertActionStyle.default) {
            UIAlertAction in
            Localize.setCurrentLanguage("ar")
        }
        
        let frAction = UIAlertAction(title: "French".localized(), style: UIAlertActionStyle.default) {
            UIAlertAction in
            Localize.setCurrentLanguage("fr")
        }
        
        let enAction = UIAlertAction(title: "English".localized(), style: UIAlertActionStyle.default) {
            UIAlertAction in
            Localize.setCurrentLanguage("en")
        }
        
        let cancelAction = UIAlertAction(title: "Cancel".localized(), style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        
        // Add the actions
        alertController.addAction(arAction)
        alertController.addAction(frAction)
        alertController.addAction(enAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func btnNxtAction(_ sender: UIButton) {
    }
    
    
    
}



